package com.elderguard.safety;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

final class SafetyPrefs {
    static final String ACTION_SOS = "com.elderguard.safety.ACTION_SOS";
    static final String ACTION_CHECK_IN_OK = "com.elderguard.safety.ACTION_CHECK_IN_OK";
    static final String ACTION_START_MONITORING = "com.elderguard.safety.ACTION_START_MONITORING";
    static final String ACTION_STOP_MONITORING = "com.elderguard.safety.ACTION_STOP_MONITORING";

    private static final String PREFS = "elderguard";
    private static final String CONTACTS = "contacts";
    private static final String SAFE_LAT = "safe_lat";
    private static final String SAFE_LON = "safe_lon";
    private static final String SAFE_RADIUS = "safe_radius";
    private static final String SAFE_ZONE_ENABLED = "safe_zone_enabled";
    private static final String INACTIVITY_HOURS = "inactivity_hours";
    private static final String MONITORING_ENABLED = "monitoring_enabled";
    private static final String ALERT_API_URL = "alert_api_url";
    private static final String ALERT_API_KEY = "alert_api_key";

    private SafetyPrefs() {
    }

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static List<EmergencyContact> contacts(Context context) {
        ArrayList<EmergencyContact> contacts = new ArrayList<>();
        String raw = prefs(context).getString(CONTACTS, "[]");
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                contacts.add(new EmergencyContact(
                        item.optString("name"),
                        item.optString("email"),
                        item.optString("phone")
                ));
            }
        } catch (JSONException ignored) {
        }
        return contacts;
    }

    static void addContact(Context context, String name, String email, String phone) {
        List<EmergencyContact> contacts = contacts(context);
        contacts.add(new EmergencyContact(name, email, phone));
        saveContacts(context, contacts);
    }

    static void clearContacts(Context context) {
        prefs(context).edit().putString(CONTACTS, "[]").apply();
    }

    static String contactEmails(Context context) {
        StringBuilder builder = new StringBuilder();
        for (EmergencyContact contact : contacts(context)) {
            if (!contact.email.isEmpty()) {
                if (builder.length() > 0) {
                    builder.append(",");
                }
                builder.append(contact.email);
            }
        }
        return builder.toString();
    }

    private static void saveContacts(Context context, List<EmergencyContact> contacts) {
        JSONArray array = new JSONArray();
        for (EmergencyContact contact : contacts) {
            JSONObject item = new JSONObject();
            try {
                item.put("name", contact.name);
                item.put("email", contact.email);
                item.put("phone", contact.phone);
                array.put(item);
            } catch (JSONException ignored) {
            }
        }
        prefs(context).edit().putString(CONTACTS, array.toString()).apply();
    }

    static void saveSafeZone(Context context, Location location, float radiusMeters) {
        prefs(context).edit()
                .putBoolean(SAFE_ZONE_ENABLED, true)
                .putFloat(SAFE_LAT, (float) location.getLatitude())
                .putFloat(SAFE_LON, (float) location.getLongitude())
                .putFloat(SAFE_RADIUS, radiusMeters)
                .apply();
    }

    static boolean hasSafeZone(Context context) {
        return prefs(context).getBoolean(SAFE_ZONE_ENABLED, false);
    }

    static float safeRadius(Context context) {
        return prefs(context).getFloat(SAFE_RADIUS, 250f);
    }

    static Location safeLocation(Context context) {
        SharedPreferences p = prefs(context);
        Location safe = new Location("elderguard-safe-zone");
        safe.setLatitude(p.getFloat(SAFE_LAT, 0f));
        safe.setLongitude(p.getFloat(SAFE_LON, 0f));
        return safe;
    }

    static int inactivityHours(Context context) {
        return prefs(context).getInt(INACTIVITY_HOURS, 4);
    }

    static boolean monitoringEnabled(Context context) {
        return prefs(context).getBoolean(MONITORING_ENABLED, false);
    }

    static void setMonitoringEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(MONITORING_ENABLED, enabled).apply();
    }

    static void saveAlertService(Context context, String url, String apiKey) {
        prefs(context).edit()
                .putString(ALERT_API_URL, url.trim())
                .putString(ALERT_API_KEY, apiKey.trim())
                .apply();
    }

    static AlertServiceConfig alertServiceConfig(Context context) {
        SharedPreferences p = prefs(context);
        return new AlertServiceConfig(
                p.getString(ALERT_API_URL, "http://10.0.2.2:8787"),
                p.getString(ALERT_API_KEY, "dev-local-key")
        );
    }

    static boolean hasAlertService(Context context) {
        AlertServiceConfig config = alertServiceConfig(context);
        return !config.url.isEmpty() && !config.apiKey.isEmpty();
    }

    static final class EmergencyContact {
        final String name;
        final String email;
        final String phone;

        EmergencyContact(String name, String email, String phone) {
            this.name = name == null ? "" : name.trim();
            this.email = email == null ? "" : email.trim();
            this.phone = phone == null ? "" : phone.trim();
        }
    }

    static final class AlertServiceConfig {
        final String url;
        final String apiKey;

        AlertServiceConfig(String url, String apiKey) {
            this.url = url == null ? "" : url.trim();
            this.apiKey = apiKey == null ? "" : apiKey.trim();
        }
    }
}
