package com.elderguard.safety;

import android.content.Context;
import android.location.Location;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class AlertBackendClient {
    interface Callback {
        void onResult(boolean sent, String message);
    }

    private AlertBackendClient() {
    }

    static void sendAsync(Context context, String reason, String message, Location location, Callback callback) {
        Context appContext = context.getApplicationContext();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String response = send(appContext, reason, message, location);
                    if (callback != null) {
                        callback.onResult(true, response);
                    }
                } catch (Exception error) {
                    if (callback != null) {
                        callback.onResult(false, error.getMessage());
                    }
                }
            }
        }, "elderguard-alert-backend").start();
    }

    private static String send(Context context, String reason, String message, Location location) throws Exception {
        SafetyPrefs.AlertServiceConfig config = SafetyPrefs.alertServiceConfig(context);
        if (!SafetyPrefs.hasAlertService(context)) {
            throw new IllegalStateException("Falta configurar el servicio de alertas.");
        }
        if (SafetyPrefs.contacts(context).isEmpty()) {
            throw new IllegalStateException("No hay contactos configurados.");
        }

        URL url = new URL(trimSlash(config.url) + "/alerts");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(20_000);
        connection.setReadTimeout(25_000);
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        connection.setRequestProperty("X-ElderGuard-Key", config.apiKey);

        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream(), StandardCharsets.UTF_8));
        writer.write(payload(context, reason, message, location).toString());
        writer.flush();
        writer.close();

        int code = connection.getResponseCode();
        String body = read(code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream());
        if (code < 200 || code >= 300) {
            throw new IllegalStateException("Backend respondio " + code + ": " + body);
        }
        return body.isEmpty() ? "Alerta enviada." : body;
    }

    private static JSONObject payload(Context context, String reason, String message, Location location) throws Exception {
        JSONObject root = new JSONObject();
        root.put("reason", reason);
        root.put("message", message);
        root.put("deviceTime", System.currentTimeMillis());

        JSONArray contacts = new JSONArray();
        for (SafetyPrefs.EmergencyContact contact : SafetyPrefs.contacts(context)) {
            JSONObject item = new JSONObject();
            item.put("name", contact.name);
            item.put("email", contact.email);
            item.put("phone", contact.phone);
            contacts.put(item);
        }
        root.put("contacts", contacts);

        if (location != null) {
            JSONObject loc = new JSONObject();
            loc.put("lat", location.getLatitude());
            loc.put("lon", location.getLongitude());
            loc.put("accuracy", location.hasAccuracy() ? location.getAccuracy() : JSONObject.NULL);
            root.put("location", loc);
        }
        return root;
    }

    private static String read(InputStream input) throws Exception {
        if (input == null) {
            return "";
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8));
        StringBuilder builder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            builder.append(line);
        }
        return builder.toString();
    }

    private static String trimSlash(String value) {
        while (value.endsWith("/")) {
            value = value.substring(0, value.length() - 1);
        }
        return value;
    }
}
