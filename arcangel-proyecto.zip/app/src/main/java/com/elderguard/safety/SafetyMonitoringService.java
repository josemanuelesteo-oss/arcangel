package com.elderguard.safety;

import android.Manifest;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

public class SafetyMonitoringService extends Service implements SensorEventListener, LocationListener {
    static final String CHANNEL_MONITORING = "elderguard_monitoring";
    private static final int NOTIFICATION_MONITORING = 7000;
    private static final float FREE_FALL_G = 0.55f;
    private static final float IMPACT_G = 2.7f;
    private static final float REST_GYRO_RAD = 0.45f;
    private static final long IMPACT_WINDOW_MS = 1400L;
    private static final long REST_WINDOW_MS = 6500L;
    private static final long LOCATION_INTERVAL_MS = 60_000L;
    private static final long CHECK_IN_GRACE_MS = 5 * 60_000L;
    private static final long REPEATED_ALERT_COOLDOWN_MS = 30 * 60_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SensorManager sensorManager;
    private LocationManager locationManager;
    private Location lastLocation;
    private long freeFallAt;
    private long impactAt;
    private long lastMeaningfulMovementAt;
    private long checkInStartedAt;
    private long lastFallAlertAt;
    private long lastSafeZoneAlertAt;
    private boolean checkInPending;

    private final Runnable inactivityRunnable = new Runnable() {
        @Override
        public void run() {
            evaluateInactivity();
            handler.postDelayed(this, 60_000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        SafetyPrefs.setMonitoringEnabled(this, true);
        EmergencyAlertManager.ensureChannels(this);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        lastMeaningfulMovementAt = SystemClock.elapsedRealtime();
        startForeground(NOTIFICATION_MONITORING, buildMonitoringNotification());
        registerSensors();
        registerLocation();
        handler.post(inactivityRunnable);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (SafetyPrefs.ACTION_SOS.equals(action)) {
            EmergencyAlertManager.sendEmergency(this, "botón SOS", lastLocation);
        } else if (SafetyPrefs.ACTION_CHECK_IN_OK.equals(action)) {
            checkInPending = false;
            checkInStartedAt = 0L;
            lastMeaningfulMovementAt = SystemClock.elapsedRealtime();
            EmergencyAlertManager.clearCheckIn(this);
        } else if (SafetyPrefs.ACTION_STOP_MONITORING.equals(action)) {
            stopSelf();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        SafetyPrefs.setMonitoringEnabled(this, false);
        handler.removeCallbacksAndMessages(null);
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        if (locationManager != null) {
            locationManager.removeUpdates(this);
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        long now = SystemClock.elapsedRealtime();
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float g = accelerationG(event.values);
            if (g < FREE_FALL_G) {
                freeFallAt = now;
            }
            if (g > IMPACT_G && freeFallAt > 0 && now - freeFallAt <= IMPACT_WINDOW_MS) {
                impactAt = now;
            }
            if (Math.abs(g - 1f) > 0.18f) {
                lastMeaningfulMovementAt = now;
            }
        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE && impactAt > 0) {
            float gyro = magnitude(event.values);
            if (gyro < REST_GYRO_RAD && now - impactAt >= REST_WINDOW_MS) {
                if (now - lastFallAlertAt >= REPEATED_ALERT_COOLDOWN_MS) {
                    EmergencyAlertManager.sendEmergency(this, "posible caída", lastLocation);
                    lastFallAlertAt = now;
                }
                freeFallAt = 0L;
                impactAt = 0L;
            }
        } else if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            lastMeaningfulMovementAt = now;
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onLocationChanged(Location location) {
        lastLocation = location;
        evaluateSafeZone(location);
    }

    private void registerSensors() {
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        Sensor steps = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
        if (gyroscope != null) {
            sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
        }
        if (steps != null) {
            sensorManager.registerListener(this, steps, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    private void registerLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    LOCATION_INTERVAL_MS,
                    25f,
                    this
            );
        }
        if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    LOCATION_INTERVAL_MS,
                    50f,
                    this
            );
        }
        Location gps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        Location network = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        lastLocation = gps != null ? gps : network;
    }

    private void evaluateSafeZone(Location current) {
        if (!SafetyPrefs.hasSafeZone(this)) {
            return;
        }
        Location safe = SafetyPrefs.safeLocation(this);
        float distance = current.distanceTo(safe);
        float radius = SafetyPrefs.safeRadius(this);
        long now = SystemClock.elapsedRealtime();
        if (distance > radius && now - lastSafeZoneAlertAt >= REPEATED_ALERT_COOLDOWN_MS) {
            EmergencyAlertManager.sendEmergency(this, "salida de zona segura", current);
            lastSafeZoneAlertAt = now;
        }
    }

    private void evaluateInactivity() {
        long now = SystemClock.elapsedRealtime();
        long inactivityLimit = SafetyPrefs.inactivityHours(this) * 60L * 60L * 1000L;
        if (!checkInPending && now - lastMeaningfulMovementAt >= inactivityLimit) {
            checkInPending = true;
            checkInStartedAt = now;
            EmergencyAlertManager.showCheckIn(this, lastLocation);
        }
        if (checkInPending && now - checkInStartedAt >= CHECK_IN_GRACE_MS) {
            EmergencyAlertManager.clearCheckIn(this);
            EmergencyAlertManager.sendEmergency(this, "inactividad prolongada sin confirmación", lastLocation);
            checkInPending = false;
            lastMeaningfulMovementAt = now;
        }
    }

    private Notification buildMonitoringNotification() {
        Intent appIntent = new Intent(this, MainActivity.class);
        PendingIntent appPending = PendingIntent.getActivity(
                this,
                10,
                appIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent sosIntent = new Intent(this, SafetyMonitoringService.class);
        sosIntent.setAction(SafetyPrefs.ACTION_SOS);
        PendingIntent sosPending = PendingIntent.getService(
                this,
                11,
                sosIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_MONITORING)
                .setSmallIcon(R.drawable.ic_guard)
                .setContentTitle("ElderGuard activo")
                .setContentText("Monitorizando caídas, actividad y zona segura.")
                .setContentIntent(appPending)
                .setOngoing(true)
                .addAction(R.drawable.ic_guard, "SOS", sosPending)
                .build();
    }

    private static float accelerationG(float[] values) {
        return magnitude(values) / SensorManager.GRAVITY_EARTH;
    }

    private static float magnitude(float[] values) {
        return (float) Math.sqrt(values[0] * values[0] + values[1] * values[1] + values[2] * values[2]);
    }
}
