package com.elderguard.safety;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PERMISSION_REQUEST = 100;
    private static final int VOICE_REQUEST = 101;
    private static final int MAX_CONTENT_DP = 560;

    private final int ink = Color.rgb(15, 23, 42);
    private final int muted = Color.rgb(71, 85, 105);
    private final int surface = Color.rgb(248, 250, 252);
    private final int card = Color.WHITE;
    private final int line = Color.rgb(226, 232, 240);
    private final int teal = Color.rgb(13, 116, 112);
    private final int tealDark = Color.rgb(17, 94, 89);
    private final int danger = Color.rgb(190, 18, 60);
    private final int dangerDark = Color.rgb(159, 18, 57);
    private final int slate = Color.rgb(71, 85, 105);

    private LinearLayout content;
    private LinearLayout nav;
    private ScrollView scroll;
    private LocationManager locationManager;
    private int currentTab;

    private EditText nameInput;
    private EditText emailInput;
    private EditText phoneInput;
    private EditText alertUrlInput;
    private EditText alertKeyInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EmergencyAlertManager.ensureChannels(this);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        styleSystemBars();
        setContentView(shell());
        showHome();
        requestCriticalPermissions();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN
                && (event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_UP || event.getKeyCode() == KeyEvent.KEYCODE_VOLUME_DOWN)
                && event.getRepeatCount() >= 2) {
            triggerSos();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null) {
                for (String phrase : matches) {
                    String normalized = phrase.toLowerCase(Locale.ROOT);
                    if (normalized.contains("ayuda") || normalized.contains("socorro") || normalized.contains("emergencia")) {
                        triggerSos();
                        return;
                    }
                }
            }
            toast("No se detecto una palabra de emergencia.");
        }
    }

    private void styleSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(surface);
        window.setNavigationBarColor(Color.WHITE);
        if (Build.VERSION.SDK_INT >= 23) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    private View shell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(surface);

        scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(0, 0, 0, dp(20));

        LinearLayout frame = new LinearLayout(this);
        frame.setGravity(Gravity.CENTER_HORIZONTAL);
        frame.setPadding(dp(16), dp(22), dp(16), dp(28));
        scroll.addView(frame, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
        ));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        frame.addView(content, new LinearLayout.LayoutParams(
                Math.min(getResources().getDisplayMetrics().widthPixels - dp(32), dp(MAX_CONTENT_DP)),
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(12), dp(10), dp(12), dp(12));
        nav.setBackgroundColor(Color.WHITE);
        root.addView(nav, fullWidth());
        addNavButton("Inicio", 0);
        addNavButton("Contactos", 1);
        addNavButton("Seguridad", 2);

        if (Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                    int bottom = Build.VERSION.SDK_INT >= 30
                            ? insets.getInsets(WindowInsets.Type.navigationBars()).bottom
                            : insets.getSystemWindowInsetBottom();
                    nav.setPadding(dp(12), dp(10), dp(12), dp(12) + bottom);
                    scroll.setPadding(0, 0, 0, dp(24) + bottom);
                    return insets;
                }
            });
        }

        return root;
    }

    private void showHome() {
        currentTab = 0;
        reset("ElderGuard", "Seguridad clara para personas mayores");
        refreshNav();

        LinearLayout statusCard = cardBox();
        statusCard.addView(sectionTitle("Proteccion activa"));
        statusCard.addView(sectionText("Caidas, inactividad, zona segura y aviso automatico por email."));
        statusCard.addView(secondaryButton("Activar monitorizacion", teal, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startMonitoring();
            }
        }));
        content.addView(statusCard);

        LinearLayout sosCard = cardBox();
        sosCard.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView help = label("Emergencia", 18, true);
        help.setGravity(Gravity.CENTER);
        sosCard.addView(help, fullWidth());
        sosCard.addView(sectionTextCentered("Pulsa este boton si necesitas avisar inmediatamente a tus familiares."));
        Button sos = emergencyButton(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                triggerSos();
            }
        });
        sosCard.addView(sos);
        content.addView(sosCard);

        LinearLayout actions = cardBox();
        actions.addView(sectionTitle("Accesos rapidos"));
        actions.addView(secondaryButton("Alerta por voz", tealDark, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listenForEmergencyWord();
            }
        }));
        actions.addView(secondaryButton("Guardar zona segura", slate, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveSafeZone();
            }
        }));
        content.addView(actions);

        showContactSummary();
    }

    private void showContactSummary() {
        LinearLayout contactCard = cardBox();
        contactCard.addView(sectionTitle("Familiares configurados"));
        List<SafetyPrefs.EmergencyContact> contacts = SafetyPrefs.contacts(this);
        if (contacts.isEmpty()) {
            contactCard.addView(sectionText("Anade al menos un familiar para recibir alertas automaticas."));
            contactCard.addView(secondaryButton("Anadir contacto", teal, new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showContacts();
                }
            }));
        } else {
            for (SafetyPrefs.EmergencyContact contact : contacts) {
                contactCard.addView(contactRow(contact));
            }
        }
        content.addView(contactCard);
    }

    private void showContacts() {
        currentTab = 1;
        reset("Contactos", "Familiares que recibiran alertas");
        refreshNav();

        LinearLayout form = cardBox();
        form.addView(sectionTitle("Nuevo contacto"));
        nameInput = input("Nombre");
        emailInput = input("Email");
        phoneInput = input("Telefono");
        phoneInput.setInputType(InputType.TYPE_CLASS_PHONE);
        form.addView(nameInput);
        form.addView(emailInput);
        form.addView(phoneInput);
        form.addView(primaryButton("Anadir contacto", teal, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addContact();
            }
        }));
        content.addView(form);

        LinearLayout list = cardBox();
        list.addView(sectionTitle("Lista actual"));
        List<SafetyPrefs.EmergencyContact> contacts = SafetyPrefs.contacts(this);
        if (contacts.isEmpty()) {
            list.addView(sectionText("Todavia no hay contactos."));
        } else {
            for (SafetyPrefs.EmergencyContact contact : contacts) {
                list.addView(contactRow(contact));
            }
            list.addView(secondaryButton("Borrar todos", slate, new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SafetyPrefs.clearContacts(MainActivity.this);
                    showContacts();
                    toast("Contactos borrados.");
                }
            }));
        }
        content.addView(list);
    }

    private void showSafety() {
        currentTab = 2;
        reset("Seguridad", "Ajustes esenciales");
        refreshNav();

        LinearLayout monitorCard = cardBox();
        monitorCard.addView(sectionTitle("Monitorizacion"));
        Switch monitorSwitch = new Switch(this);
        monitorSwitch.setText("Servicio activo en segundo plano");
        monitorSwitch.setTextSize(18);
        monitorSwitch.setTextColor(ink);
        monitorSwitch.setPadding(0, dp(8), 0, dp(8));
        monitorSwitch.setChecked(SafetyPrefs.monitoringEnabled(this));
        monitorSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean active) {
                if (active) {
                    startMonitoring();
                } else {
                    stopMonitoring();
                }
            }
        });
        monitorCard.addView(monitorSwitch);
        monitorCard.addView(primaryButton("Guardar esta ubicacion como zona segura", teal, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveSafeZone();
            }
        }));
        monitorCard.addView(secondaryButton("Abrir ajustes de ubicacion", slate, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            }
        }));
        monitorCard.addView(sectionText("Anade el acceso rapido SOS en Ajustes rapidos de Android para pedir ayuda sin abrir la app."));
        content.addView(monitorCard);

        LinearLayout alertCard = cardBox();
        alertCard.addView(sectionTitle("Servicio de alertas"));
        alertCard.addView(sectionText("Envia emails automaticamente desde un servidor seguro. La familia no necesita configurar Gmail ni contrasenas SMTP."));
        SafetyPrefs.AlertServiceConfig config = SafetyPrefs.alertServiceConfig(this);
        alertUrlInput = input("URL del servicio");
        alertUrlInput.setText(config.url);
        alertKeyInput = input("Clave de la app");
        alertKeyInput.setText(config.apiKey);
        alertCard.addView(alertUrlInput);
        alertCard.addView(alertKeyInput);
        alertCard.addView(primaryButton("Guardar servicio de alertas", teal, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveAlertServiceSettings();
            }
        }));
        alertCard.addView(secondaryButton("Enviar alerta de prueba", slate, new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendTestAlert();
            }
        }));
        content.addView(alertCard);
    }

    private void addContact() {
        String name = nameInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String phone = phoneInput.getText().toString().trim();
        if (name.isEmpty() || email.isEmpty()) {
            toast("Nombre y email son obligatorios.");
            return;
        }
        SafetyPrefs.addContact(this, name, email, phone);
        showContacts();
        toast("Contacto anadido.");
    }

    private boolean saveAlertServiceSettings() {
        if (alertUrlInput.getText().toString().trim().isEmpty()
                || alertKeyInput.getText().toString().trim().isEmpty()) {
            toast("Completa URL y clave del servicio.");
            return false;
        }
        SafetyPrefs.saveAlertService(
                this,
                alertUrlInput.getText().toString(),
                alertKeyInput.getText().toString()
        );
        toast("Servicio de alertas guardado.");
        return true;
    }

    private void sendTestAlert() {
        if (!saveAlertServiceSettings()) {
            return;
        }
        AlertBackendClient.sendAsync(this, "prueba manual", "ElderGuard: esta es una alerta automatica de prueba.", null, new AlertBackendClient.Callback() {
            @Override
            public void onResult(boolean sent, String message) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (sent) {
                            showMessage("Alerta enviada", "La prueba se envio correctamente a los contactos configurados.");
                        } else {
                            showMessage("No se pudo enviar", alertHelp(message));
                        }
                    }
                });
            }
        });
    }

    private String alertHelp(String message) {
        StringBuilder builder = new StringBuilder();
        builder.append(message == null ? "Error desconocido." : message);
        builder.append("\n\nRevisa estos puntos:\n");
        builder.append("- Debe haber al menos un contacto con email.\n");
        builder.append("- La URL del servicio debe estar disponible desde este movil.\n");
        builder.append("- La clave debe coincidir con la configurada en el backend.\n");
        builder.append("- El movil debe tener internet.\n");
        builder.append("- Si pruebas en movil fisico, no uses 10.0.2.2; usa la IP local del ordenador o un servidor desplegado.");
        return builder.toString();
    }

    private void showMessage(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Aceptar", null)
                .show();
    }

    private void reset(String title, String subtitle) {
        content.removeAllViews();
        TextView titleView = label(title, 32, true);
        TextView subtitleView = label(subtitle, 17, false);
        subtitleView.setTextColor(muted);
        subtitleView.setPadding(0, dp(4), 0, dp(18));
        content.addView(titleView);
        content.addView(subtitleView);
        scroll.post(new Runnable() {
            @Override
            public void run() {
                scroll.scrollTo(0, 0);
            }
        });
    }

    private void requestCriticalPermissions() {
        ArrayList<String> permissions = new ArrayList<>();
        addPermission(permissions, Manifest.permission.ACCESS_FINE_LOCATION);
        addPermission(permissions, Manifest.permission.RECORD_AUDIO);
        addPermission(permissions, Manifest.permission.CALL_PHONE);
        if (Build.VERSION.SDK_INT >= 29) {
            addPermission(permissions, Manifest.permission.ACTIVITY_RECOGNITION);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            addPermission(permissions, Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!permissions.isEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toArray(new String[0]), PERMISSION_REQUEST);
        }
    }

    private void addPermission(ArrayList<String> permissions, String permission) {
        if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
            permissions.add(permission);
        }
    }

    private void startMonitoring() {
        SafetyPrefs.setMonitoringEnabled(this, true);
        Intent intent = new Intent(this, SafetyMonitoringService.class);
        intent.setAction(SafetyPrefs.ACTION_START_MONITORING);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        toast("Monitorizacion activa.");
    }

    private void stopMonitoring() {
        SafetyPrefs.setMonitoringEnabled(this, false);
        stopService(new Intent(this, SafetyMonitoringService.class));
        toast("Monitorizacion pausada.");
    }

    private void triggerSos() {
        Intent intent = new Intent(this, SafetyMonitoringService.class);
        intent.setAction(SafetyPrefs.ACTION_SOS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        toast("SOS enviado a los contactos.");
    }

    private void saveSafeZone() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestCriticalPermissions();
            return;
        }
        Location last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (last == null) {
            last = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        }
        if (last == null) {
            toast("Activa ubicacion y espera unos segundos.");
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            return;
        }
        SafetyPrefs.saveSafeZone(this, last, 250f);
        toast("Zona segura guardada con radio de 250 m.");
    }

    private void listenForEmergencyWord() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Di ayuda, socorro o emergencia");
        startActivityForResult(intent, VOICE_REQUEST);
    }

    private LinearLayout cardBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(16), dp(18), dp(18));
        box.setBackground(rounded(card, dp(18), line, 1));
        LinearLayout.LayoutParams params = fullWidth();
        params.setMargins(0, 0, 0, dp(14));
        box.setLayoutParams(params);
        return box;
    }

    private View contactRow(SafetyPrefs.EmergencyContact contact) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        row.setBackground(rounded(Color.rgb(248, 250, 252), dp(14), line, 1));
        LinearLayout.LayoutParams params = fullWidth();
        params.setMargins(0, dp(8), 0, 0);
        row.setLayoutParams(params);
        row.addView(label(contact.name, 18, true));
        row.addView(small(contact.email));
        if (!contact.phone.isEmpty()) {
            row.addView(small(contact.phone));
        }
        return row;
    }

    private TextView sectionTitle(String text) {
        TextView view = label(text, 20, true);
        view.setPadding(0, 0, 0, dp(6));
        return view;
    }

    private TextView sectionText(String text) {
        TextView view = label(text, 15, false);
        view.setTextColor(muted);
        view.setLineSpacing(0f, 1.12f);
        view.setPadding(0, dp(2), 0, dp(10));
        return view;
    }

    private TextView sectionTextCentered(String text) {
        TextView view = sectionText(text);
        view.setGravity(Gravity.CENTER);
        return view;
    }

    private TextView small(String text) {
        TextView view = label(text, 14, false);
        view.setTextColor(muted);
        return view;
    }

    private EditText input(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setSingleLine(true);
        input.setTextSize(17);
        input.setTextColor(ink);
        input.setHintTextColor(Color.rgb(100, 116, 139));
        input.setPadding(dp(14), 0, dp(14), 0);
        input.setMinHeight(dp(52));
        input.setBackground(rounded(Color.WHITE, dp(14), line, 1));
        LinearLayout.LayoutParams params = fullWidth();
        params.setMargins(0, dp(8), 0, 0);
        input.setLayoutParams(params);
        return input;
    }

    private Button emergencyButton(View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText("SOS");
        button.setAllCaps(false);
        button.setTextSize(34);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        button.setBackground(rounded(danger, dp(36), dangerDark, 2));
        button.setOnClickListener(listener);
        button.setMinHeight(dp(112));
        button.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, dp(8), 0, 0);
        button.setLayoutParams(params);
        return button;
    }

    private Button primaryButton(String label, int color, View.OnClickListener listener) {
        return actionButton(label, color, Color.WHITE, listener, 54);
    }

    private Button secondaryButton(String label, int color, View.OnClickListener listener) {
        return actionButton(label, color, Color.WHITE, listener, 50);
    }

    private Button actionButton(String label, int color, int textColor, View.OnClickListener listener, int minHeightDp) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextSize(16);
        button.setTextColor(textColor);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setBackground(rounded(color, dp(16), darken(color), 1));
        button.setOnClickListener(listener);
        button.setMinHeight(dp(minHeightDp));
        button.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams params = fullWidth();
        params.setMargins(0, dp(10), 0, 0);
        button.setLayoutParams(params);
        return button;
    }

    private void addNavButton(String label, int tab) {
        Button button = new Button(this);
        button.setTag(tab);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(48));
        button.setPadding(dp(4), dp(4), dp(4), dp(4));
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selected = (Integer) view.getTag();
                if (selected == 0) {
                    showHome();
                } else if (selected == 1) {
                    showContacts();
                } else {
                    showSafety();
                }
            }
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        params.setMargins(dp(4), 0, dp(4), 0);
        nav.addView(button, params);
    }

    private void refreshNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            Button button = (Button) nav.getChildAt(i);
            int tab = (Integer) button.getTag();
            boolean active = tab == currentTab;
            button.setTextColor(active ? Color.WHITE : teal);
            button.setTypeface(Typeface.DEFAULT, active ? Typeface.BOLD : Typeface.NORMAL);
            button.setBackground(rounded(active ? teal : Color.rgb(236, 253, 245), dp(16), active ? tealDark : Color.rgb(187, 247, 208), 1));
        }
    }

    private TextView label(String value, int sp, boolean bold) {
        TextView textView = new TextView(this);
        textView.setText(value);
        textView.setTextSize(sp);
        textView.setTextColor(ink);
        textView.setIncludeFontPadding(true);
        if (bold) {
            textView.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return textView;
    }

    private GradientDrawable rounded(int color, int radius, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (strokeDp > 0) {
            drawable.setStroke(dp(strokeDp), strokeColor);
        }
        return drawable;
    }

    private int darken(int color) {
        return Color.rgb(
                Math.max(0, (int) (Color.red(color) * 0.82f)),
                Math.max(0, (int) (Color.green(color) * 0.82f)),
                Math.max(0, (int) (Color.blue(color) * 0.82f))
        );
    }

    private LinearLayout.LayoutParams fullWidth() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
