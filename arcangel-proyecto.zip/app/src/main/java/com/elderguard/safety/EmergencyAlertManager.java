package com.elderguard.safety;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

final class EmergencyAlertManager {
    static final String CHANNEL_ALERTS = "elderguard_alerts";
    static final int NOTIFICATION_EMERGENCY = 7001;
    static final int NOTIFICATION_CHECK_IN = 7002;
    private static final int NOTIFICATION_EMAIL_STATUS = 7003;

    private EmergencyAlertManager() {
    }

    static void ensureChannels(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel(
                CHANNEL_ALERTS,
                context.getString(R.string.alerts_channel),
                NotificationManager.IMPORTANCE_HIGH
        ));
        manager.createNotificationChannel(new NotificationChannel(
                SafetyMonitoringService.CHANNEL_MONITORING,
                context.getString(R.string.monitoring_channel),
                NotificationManager.IMPORTANCE_LOW
        ));
    }

    static void sendEmergency(Context context, String reason, Location location) {
        String emails = SafetyPrefs.contactEmails(context);
        String text = buildMessage(reason, location);
        showEmergencyNotification(context, "alerta detectada", text);

        if (emails.isEmpty()) {
            showEmergencyNotification(context, "sin contactos", "No hay familiares con email configurado.");
            return;
        }

        if (!SafetyPrefs.hasAlertService(context)) {
            showEmergencyNotification(context, "servicio no configurado", "Configura el servicio de alertas en Seguridad.");
            return;
        }

        AlertBackendClient.sendAsync(context, reason, text, location, new AlertBackendClient.Callback() {
            @Override
            public void onResult(boolean sent, String message) {
                if (sent) {
                    showStatusNotification(context, "Alerta enviada", "Aviso automatico enviado a: " + emails);
                } else {
                    showEmergencyNotification(context, "fallo enviando alerta", message == null ? "No se pudo enviar la alerta." : message);
                }
            }
        });
    }

    static void showCheckIn(Context context, Location location) {
        Intent okIntent = new Intent(context, SafetyMonitoringService.class);
        okIntent.setAction(SafetyPrefs.ACTION_CHECK_IN_OK);
        PendingIntent okPending = PendingIntent.getService(
                context,
                31,
                okIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ALERTS)
                .setSmallIcon(R.drawable.ic_guard)
                .setContentTitle("Confirma que estás bien")
                .setContentText("No se ha detectado actividad reciente.")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setOngoing(true)
                .addAction(R.drawable.ic_guard, "Estoy bien", okPending);

        if (canPostNotifications(context)) {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_CHECK_IN, builder.build());
        }
    }

    static void clearCheckIn(Context context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_CHECK_IN);
    }

    private static void showEmergencyNotification(Context context, String reason, String text) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(text)));
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                22,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ALERTS)
                .setSmallIcon(R.drawable.ic_guard)
                .setContentTitle("Alerta enviada: " + reason)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setAutoCancel(true);

        if (canPostNotifications(context)) {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_EMERGENCY, builder.build());
        }
    }

    private static void showStatusNotification(Context context, String title, String text) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ALERTS)
                .setSmallIcon(R.drawable.ic_guard)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        if (canPostNotifications(context)) {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_EMAIL_STATUS, builder.build());
        }
    }

    private static String buildMessage(String reason, Location location) {
        StringBuilder builder = new StringBuilder("ElderGuard: alerta por ");
        builder.append(reason).append(".");
        if (location != null) {
            builder.append(" Ubicación: https://maps.google.com/?q=");
            builder.append(location.getLatitude()).append(",").append(location.getLongitude());
        } else {
            builder.append(" Ubicación no disponible todavía.");
        }
        return builder.toString();
    }

    private static boolean canPostNotifications(Context context) {
        return Build.VERSION.SDK_INT < 33
                || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }
}
