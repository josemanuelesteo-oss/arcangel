# ElderGuard Alert Backend

Backend sencillo para enviar emails automaticos desde ElderGuard sin pedir SMTP ni contrasenas de Gmail a las familias.

## Configuracion

1. Crea una cuenta en Resend.
2. Verifica un dominio remitente en Resend.
3. Copia `.env.example` como `.env` en el servidor real.
4. Define:

```text
PORT=8787
ELDERGUARD_API_KEY=una-clave-larga-aleatoria
RESEND_API_KEY=re_xxxxxxxxxxxxxxxxx
FROM_EMAIL=ElderGuard <alerts@tudominio.com>
```

## Ejecutar

```bash
npm start
```

## Desplegar en Render

El repo incluye `render.yaml`, asi que Render puede crear el servicio automaticamente.

Variables que debes poner en Render:

- `RESEND_API_KEY`
- `FROM_EMAIL`

Render genera `ELDERGUARD_API_KEY` automaticamente si usas Blueprint. Copiala despues para ponerla en la app.

## Probar

```bash
curl -X POST http://localhost:8787/alerts \
  -H "Content-Type: application/json" \
  -H "X-ElderGuard-Key: dev-local-key" \
  -d "{\"reason\":\"prueba\",\"message\":\"Alerta de prueba\",\"contacts\":[{\"name\":\"Familiar\",\"email\":\"familiar@example.com\",\"phone\":\"\"}]}"
```

## App Android

En la app, ve a `Seguridad > Servicio de alertas`:

- URL del servicio: `https://tu-backend.com`
- Clave de la app: el valor de `ELDERGUARD_API_KEY`

En produccion, estos valores deberian ir ya preconfigurados en el APK para que el usuario final solo tenga que anadir familiares.
